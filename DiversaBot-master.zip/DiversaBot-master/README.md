# DiversaBot (legacy)
Management bot for DiversaTech

DiversaBot V2 here: https://github.com/thomaspwang/diversabot_V2
